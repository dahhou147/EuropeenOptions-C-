# Basic Usage

@snippet api/mongocxx/examples/logger/basic_usage.cpp Example

# Convert a Log Level to a String

@snippet api/mongocxx/examples/logger/to_string.cpp Example
